export const songsData = [
    {
        "title": "Drake - Forever",
        "authorTrack": "seonfoi",
        "preViewImagePath": "/tracks/images/JackBoys.jpg",
        "trackPath": "audio/muzlome_Travis_Scott_-_SICKO_MODE_57796090.mp3",
        "progress": 0,
        "length": 0,
    },
    {
        "title": "Linking Park - In the end",
        "authorTrack": "seonfoi",
        "preViewImagePath": "/tracks/images/JackBoys.jpg",
        "trackPath": "audio/travis_scott_-_goosebumps_feat_kendrick_lamar_muzati.net.mp3",
        "progress": 0,
        "length": 0,
    },
    {
        "title": "Travis Scott - Stop trina be God",
        "authorTrack": "seonfoi",
        "preViewImagePath": "/tracks/images/JackBoys.jpg",
        "trackPath": "audio/muzlome_Travis_Scott_-_SICKO_MODE_57796090.mp3",
        "progress": 0,
        "length": 0,
    }
]