export interface PlayerProps {
    audioElem: any;
    isplaying: any;
    setisplaying: any;
    currentSong: any;
    setCurrentSong: any;
    songs: any;
}