import React from "react";

export const ContextContactData = React.createContext({});