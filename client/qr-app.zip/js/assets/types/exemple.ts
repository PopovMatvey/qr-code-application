export interface Exemple {
    parFieldString: string;
    parFieldBoolean: boolean;
    /*...*/ 
}