import React    from 'react';
import ReactDOM from 'react-dom';
import Tabs     from './Tabs/Tabs'

ReactDOM.render(<Tabs/>, document.querySelector('#root'));