# React Challenge: сортировка и поиск данных

[Статья на сайте](http://jsraccoon.ru/react-challenge-sort-and-search)

[Демо приложения](http://fafko.github.io/react-challenge-sort-and-search/)

## Таски для галпа

* Дефолтный (просто `gulp`): запускает browsersync и решрешит при изменении js, css и html. Браузер должен открыть самостоятельно.
* Деплой (`gulp deploy`): пушит всё, что находится в папке `public` в ветку `gh-pages`. В результате сайт можно показать другу
